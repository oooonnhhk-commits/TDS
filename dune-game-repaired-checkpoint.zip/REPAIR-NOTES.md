# Dune Game repair and physics checkpoint

This is an improved development checkpoint, **not a verified release**.

## Changes in this checkpoint
- Restored TanStack Start entry files: `src/router.tsx`, `src/routes/__root.tsx`, `src/routes/index.tsx`, and `src/styles.css`.
- Added an original Three.js low-poly dune scene and Arabic interface with touch/keyboard controls, a vehicle selector, speed and traction telemetry, and 2H/4H/4L drive modes.
- Added selectable 2006 short-wheelbase desert pickup (`شاص ٢٠٠٦`) and 2005 luxury 4x4 (`لكزس LX ٤٧٠ ٢٠٠٥`) with distinct original primitive-based silhouettes, tyre proportions, chassis dimensions, torque/gear assumptions, pressure response, and suspension travel. The bodies do not use manufacturer logos or third-party model files.
- Aligned the rendered chassis to the physics body's full quaternion so pitch and roll are visible, not just yaw. Wheel pivots now visibly steer, spin, and follow suspension extension/compression.
- Added a light sand-spray particle effect when the tyres spin on soft/medium sand, plus UI readouts for lateral slip and wheelspin.
- Increased physics to three semi-fixed substeps, added a modest axle anti-roll force transfer, improved tyre-pressure/footprint influence on sand, and corrected bog accumulation so the four wheels do not multiply the same vehicle-level bog meter four times per frame.
- Increased baseline suspension damping and gave the new off-road pickup extra suspension travel. Default tyre pressure now starts at a lower sand-friendly setup.
- Hardened terrain contact when the car is airborne, rolled, or a wheel's normal-oriented ray misses: tyre probing retries with a vertical ground ray, and the chassis underside is checked even with zero grounded wheels. Body penetration now resolves along the terrain normal, not only world-up.
- Recovery now measures drop height against local terrain elevation and resets the state in-place. This avoids an unbounded recursive `place()` call when the vehicle drops below a deep/out-of-range terrain region.
- Adjusted visible wheel-arch positions on the Shas and older Lexus silhouettes so they sit outside the tyres more naturally.
- Added self-check coverage for all five vehicles, chassis finiteness and tyre contact, driving on loose sand, 4L hill-climbing, and ramp airborne/landing states.
- Fixed the share-card metadata title precedence; isolated share-card placeholder tests from the app's own public images.
- Disabled the Grok extensions script for local/build runs with `.grok/app-env.json` and updated Vercel install/build commands.

## Verification results
- `node --test scripts/*.test.mjs`: **197/197 passed**.
- Strict TypeScript check of `src/game/cars.ts`, `math.ts`, `terrain.ts`, `vehicle.ts`, and `selfcheck.ts` passed with an isolated config that avoids the broken dependency tree.
- Physics self-check passed: asphalt and loose-sand driving, steering direction, 4L-vs-2H climb, dunes, plus a ramp jump/landing run.
- A simulation of all five cars on soft sand kept all four wheels grounded, produced finite body state, and retained forward movement; this is a deterministic code-level test, not gameplay testing.
- Full-project `npm run typecheck` is still blocked because the dependency installation is incomplete (`@types/node`, `vite/client`, and other types unavailable).
- Full `npm test` TypeScript test phase and `npm run build` have not passed in this environment. Vite is missing from the partial `node_modules`; this does **not** prove a production build works.
- The game has not yet been verified in a real browser or on an Android device.

## Remaining before a public release
1. In a network-enabled environment, run `npm ci --no-audit --no-fund` and wait for it to finish successfully.
2. Run `npm run typecheck`, `npm test`, and `npm run build` again; fix any source errors that remain after dependencies are present.
3. Run `npm run dev` and test every car, wheel contact, steering/camera follow, suspension, tyre spin, sand spray, 2H/4H/4L, jump/landing, reset, and mobile performance on an actual phone.
4. Only then create the Android package (AAB) and follow Play Console's current testing/release requirements.

## Current limitations
- Vehicle geometry is handcrafted low-poly placeholder art, not production-grade photorealistic or manufacturer-exact 3D. These are more distinct silhouettes, not scans or licensed assets.
- The physics is a custom lightweight simulation, not a validated real-world engineering model. Sand depth, grip, suspension and landing tuning still require repeated hands-on playtesting.
- This checkpoint is not ready to be called published or production-ready.
