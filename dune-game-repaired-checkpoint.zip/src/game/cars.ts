export type DriveMode = "2H" | "4H" | "4L";

export type Upgrades = {
  engine: number;
  gearbox: number;
  suspStiff: number;
  suspDamp: number;
  ride: number;
  tireSize: number;
  compound: number;
  pressure: number;
  weight: number;
  color: string;
  rims: number;
  snorkel: boolean;
  lightbar: boolean;
  spare: boolean;
};

export type CarId = "watad" | "fakhr" | "qimma" | "shas06" | "lexus05";

export type CarDef = {
  id: CarId;
  name: string;
  clazz: string;
  /** Inspired-by line. Original geometry, no manufacturer marks. */
  inspired: string;
  price: number;
  mass: number;
  wheelbase: number;
  track: number;
  tireWidth: number;
  suspensionTravel: number;
  cgHeight: number;
  torque: number;
  redline: number;
  idle: number;
  gears: number[];
  finalDrive: number;
  lowRatio: number;
  brake: number;
  tireRadius: number;
  cdA: number;
  maxSteer: number;
  sandBias: number;
  stability: number;
  body: "bed" | "suv" | "wagon";
  defaultColor: string;
};

export const CARS: CarDef[] = [
  {
    id: "watad",
    name: "وتد ٢٢",
    clazz: "بيك أب قصير",
    inspired: "هيكل أصلي مستوحى من فئة البيك أب الصحراوي القصير، بدون شعارات تجارية.",
    price: 0,
    mass: 1980,
    wheelbase: 2.52,
    track: 1.56,
    tireWidth: 0.285,
    suspensionTravel: 0.25,
    cgHeight: 0.78,
    torque: 365,
    redline: 4800,
    idle: 750,
    gears: [3.5, 2.15, 1.48, 1.08, 0.86],
    finalDrive: 4.55,
    lowRatio: 2.65,
    brake: 5200,
    tireRadius: 0.43,
    cdA: 1.55,
    maxSteer: 0.58,
    sandBias: 1.12,
    stability: 0.82,
    body: "bed",
    defaultColor: "#d7c4a2",
  },
  {
    id: "fakhr",
    name: "فخر ٢٠",
    clazz: "دفع رباعي فاخر",
    inspired: "هيكل أصلي مستوحى من فئة الدفع الرباعي الفاخر الطويل، بدون شعارات تجارية.",
    price: 9800,
    mass: 2680,
    wheelbase: 2.98,
    track: 1.7,
    tireWidth: 0.275,
    suspensionTravel: 0.22,
    cgHeight: 0.7,
    torque: 560,
    redline: 5200,
    idle: 700,
    gears: [3.7, 2.25, 1.52, 1.12, 0.84, 0.68],
    finalDrive: 3.95,
    lowRatio: 2.45,
    brake: 6800,
    tireRadius: 0.41,
    cdA: 1.28,
    maxSteer: 0.5,
    sandBias: 0.86,
    stability: 1.15,
    body: "suv",
    defaultColor: "#1c1e22",
  },
  {
    id: "qimma",
    name: "قمة ١٦",
    clazz: "واجن كلاسيكي",
    inspired: "هيكل أصلي مستوحى من فئة الواجن الكلاسيكي، بدون شعارات تجارية.",
    price: 7200,
    mass: 2420,
    wheelbase: 2.74,
    track: 1.62,
    tireWidth: 0.285,
    suspensionTravel: 0.24,
    cgHeight: 0.74,
    torque: 455,
    redline: 4900,
    idle: 720,
    gears: [3.55, 2.18, 1.5, 1.1, 0.88],
    finalDrive: 4.2,
    lowRatio: 2.55,
    brake: 5900,
    tireRadius: 0.42,
    cdA: 1.4,
    maxSteer: 0.54,
    sandBias: 1,
    stability: 1,
    body: "wagon",
    defaultColor: "#1d3a32",
  },
  {
    id: "shas06",
    name: "شاص ٢٠٠٦",
    clazz: "بيك أب صحراوي قصير",
    inspired: "تصميم أصلي مستوحى من بيك أب الطرق الوعرة موديل 2006، دون شعارات أو نسخ حرفي للشكل التجاري.",
    price: 8600,
    mass: 2240,
    wheelbase: 2.73,
    track: 1.62,
    tireWidth: 0.305,
    suspensionTravel: 0.31,
    cgHeight: 0.82,
    torque: 360,
    redline: 4200,
    idle: 680,
    gears: [3.83, 2.06, 1.36, 1.0, 0.82],
    finalDrive: 4.3,
    lowRatio: 2.28,
    brake: 5700,
    tireRadius: 0.45,
    cdA: 1.72,
    maxSteer: 0.59,
    sandBias: 1.15,
    stability: 0.82,
    body: "bed",
    defaultColor: "#cdbb99",
  },
  {
    id: "lexus05",
    name: "لكزس LX ٤٧٠ ٢٠٠٥",
    clazz: "دفع رباعي فاخر كلاسيكي",
    inspired: "إعداد قيادة وتصميم أصلي مستوحى من فئة سيارات الدفع الرباعي الفاخرة مطلع الألفينات، دون شعارات تجارية.",
    price: 11200,
    mass: 2520,
    wheelbase: 2.85,
    track: 1.62,
    tireWidth: 0.275,
    suspensionTravel: 0.28,
    cgHeight: 0.72,
    torque: 434,
    redline: 5200,
    idle: 650,
    gears: [3.52, 2.04, 1.40, 1.00, 0.716],
    finalDrive: 3.91,
    lowRatio: 2.49,
    brake: 6600,
    tireRadius: 0.405,
    cdA: 1.38,
    maxSteer: 0.49,
    sandBias: 0.94,
    stability: 1.08,
    body: "suv",
    defaultColor: "#1f2726",
  },
];

export const PAINTS = ["#d7c4a2", "#efe8dc", "#1c1e22", "#6e1e1a", "#1d3a32", "#8a5a32", "#c45a28", "#243044"];

export function defaultUpgrades(car: CarDef): Upgrades {
  return {
    engine: 0,
    gearbox: 0,
    suspStiff: 1,
    suspDamp: 1,
    ride: 0,
    tireSize: 1,
    compound: 1,
    pressure: 0.86,
    weight: 0,
    color: car.defaultColor,
    rims: 0,
    snorkel: car.body === "bed",
    lightbar: false,
    spare: car.body !== "suv",
  };
}

export type ResolvedCar = CarDef & {
  mass: number;
  torque: number;
  tireRadius: number;
  cgHeight: number;
  spring: number;
  damper: number;
  restLength: number;
  travel: number;
  brake: number;
  grip: number;
  pressure: number;
  color: string;
  lowRatio: number;
};

export function resolveCar(car: CarDef, up: Upgrades): ResolvedCar {
  const mass = car.mass * (1 - 0.028 * up.weight) + (up.snorkel ? 18 : 0) + (up.lightbar ? 14 : 0) + (up.spare ? 22 : 0);
  const torque = car.torque * (1 + 0.075 * up.engine);
  const tireRadius = car.tireRadius * up.tireSize;
  const tireWidth = car.tireWidth * (0.88 + 0.12 * up.tireSize);
  const cg = car.cgHeight + up.ride * 0.45 - up.weight * 0.015;
  const restLength = 0.4 + up.ride;
  const travel = car.suspensionTravel + Math.max(0, up.ride) * 0.3;
  const targetComp = 0.12;
  const spring = ((mass * 9.81) / (4 * targetComp)) * up.suspStiff;
  const damper = 2 * Math.sqrt(spring * (mass / 4)) * 0.62 * up.suspDamp;
  const brake = car.brake * (1 + 0.04 * up.engine);
  return {
    ...car,
    mass,
    torque,
    tireRadius,
    tireWidth,
    cgHeight: cg,
    spring,
    damper,
    restLength,
    travel,
    brake,
    grip: up.compound,
    pressure: up.pressure,
    color: up.color,
    lowRatio: car.lowRatio * (1 + 0.04 * up.gearbox),
    gears: car.gears.map((g, i) => g * (1 + up.gearbox * (i === 0 ? 0.06 : -0.02))),
  };
}

export function ratings(car: ResolvedCar) {
  const topGear = car.gears[car.gears.length - 1] * car.finalDrive;
  const vMax = ((car.redline * Math.PI) / 30 / topGear) * car.tireRadius * 3.6;
  return {
    accel: clampRating((car.torque / car.mass) * 220),
    speed: clampRating(vMax / 2.1),
    sand: clampRating(54 * car.sandBias * car.grip * (1.15 - (car.pressure - 0.75) * 0.35) * (2200 / car.mass)),
    climb: clampRating((car.torque * car.lowRatio) / car.mass * 95 * car.sandBias),
    stable: clampRating(70 * car.stability * (1.55 / car.track) * (0.78 / car.cgHeight) * 1.35),
    brake: clampRating(car.brake / car.mass * 42),
  };
}

function clampRating(n: number) {
  return Math.max(8, Math.min(99, Math.round(n)));
}

export function carById(id: string) {
  return CARS.find((c) => c.id === id) ?? CARS[0];
}

export const UPGRADE_META: { key: keyof Upgrades; label: string; min: number; max: number; step: number; cost: (level: number) => number }[] = [
  { key: "engine", label: "قوة المحرك", min: 0, max: 5, step: 1, cost: (n) => 480 * (n + 1) },
  { key: "gearbox", label: "القير", min: 0, max: 3, step: 1, cost: (n) => 420 * (n + 1) },
  { key: "weight", label: "تخفيف الوزن", min: 0, max: 4, step: 1, cost: (n) => 360 * (n + 1) },
  { key: "suspStiff", label: "قساوة التعليق", min: 0.72, max: 1.4, step: 0.04, cost: () => 260 },
  { key: "suspDamp", label: "التخميد", min: 0.65, max: 1.45, step: 0.05, cost: () => 240 },
  { key: "ride", label: "ارتفاع السيارة", min: -0.06, max: 0.12, step: 0.01, cost: () => 180 },
  { key: "tireSize", label: "حجم الإطار", min: 0.92, max: 1.14, step: 0.02, cost: () => 300 },
  { key: "compound", label: "تماسك الإطار", min: 0.86, max: 1.24, step: 0.02, cost: () => 340 },
  { key: "pressure", label: "ضغط الإطار", min: 0.72, max: 1.28, step: 0.02, cost: () => 80 },
];
