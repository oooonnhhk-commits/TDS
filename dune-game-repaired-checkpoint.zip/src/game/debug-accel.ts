import { CARS, defaultUpgrades, resolveCar } from "./cars";
import { axesOf, len } from "./math";
import { flatField } from "./terrain";
import { Vehicle } from "./vehicle";

const watad = resolveCar(CARS[0], defaultUpgrades(CARS[0]));
console.log("mass", watad.mass, "torque", watad.torque, "spring", watad.spring.toFixed(0), "rest", watad.restLength);
const flat = flatField("asphalt");
const car = new Vehicle(watad);
car.place(0, 0, 0, flat);
for (let s = 1; s <= 6; s++) {
  const before = car.speedMs();
  let jz = 0;
  let jx = 0;
  let jy = 0;
  car.debugPen = 0;
  for (let i = 0; i < 60; i++) {
    car.step(1 / 60, { throttle: 1, brake: 0, steer: 0, handbrake: false }, flat);
    jz += car.debugJ.z;
    jx += car.debugJ.x;
    jy += car.debugJ.y;
  }
  console.log(
    JSON.stringify({
      s,
      sms: +car.speedMs().toFixed(2),
      ds: +(car.speedMs() - before).toFixed(2),
      dvz: +(-jz / car.car.mass).toFixed(2),
      dvx: +(jx / car.car.mass).toFixed(2),
      dvy: +(jy / car.car.mass).toFixed(2),
      pen: +car.debugPen.toFixed(3),
      gear: car.gear,
      rpm: Math.round(car.rpm),
      spin: +car.wheelSpin.toFixed(2),
    }),
  );
}
