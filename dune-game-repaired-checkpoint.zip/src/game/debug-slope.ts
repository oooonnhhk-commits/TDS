import { CARS, defaultUpgrades, resolveCar } from "./cars";
import { slopeField } from "./terrain";
import { Vehicle } from "./vehicle";

const watad = resolveCar(CARS[0], defaultUpgrades(CARS[0]));
const slope = slopeField(0.42, "hard");
for (const mode of ["4L", "4H", "2H"] as const) {
  const car = new Vehicle(watad);
  car.drive = mode;
  car.place(0, 0, 0, slope);
  console.log("\nMODE", mode, "start y", car.pos.y.toFixed(2), "z", car.pos.z.toFixed(2));
  for (let s = 1; s <= 4; s++) {
    for (let i = 0; i < 60; i++) car.step(1 / 60, { throttle: 1, brake: 0, steer: 0, handbrake: false }, slope);
    console.log(
      s + "s",
      "y",
      car.pos.y.toFixed(2),
      "z",
      car.pos.z.toFixed(2),
      "sms",
      car.speedMs().toFixed(2),
      "vz",
      car.vel.z.toFixed(2),
      "gear",
      car.gear,
      "g",
      car.wheels.filter((w) => w.grounded).length,
      "spin",
      car.wheelSpin.toFixed(2),
      "bog",
      car.bog.toFixed(2),
      "rpm",
      Math.round(car.rpm),
    );
  }
}
