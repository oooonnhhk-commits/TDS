export type Vec3 = { x: number; y: number; z: number };
export type Quat = { x: number; y: number; z: number; w: number };

export const V = (x = 0, y = 0, z = 0): Vec3 => ({ x, y, z });

export function vset(o: Vec3, x: number, y: number, z: number) {
  o.x = x;
  o.y = y;
  o.z = z;
  return o;
}

export function vcopy(o: Vec3, a: Vec3) {
  o.x = a.x;
  o.y = a.y;
  o.z = a.z;
  return o;
}

export function add(a: Vec3, b: Vec3): Vec3 {
  return { x: a.x + b.x, y: a.y + b.y, z: a.z + b.z };
}

export function sub(a: Vec3, b: Vec3): Vec3 {
  return { x: a.x - b.x, y: a.y - b.y, z: a.z - b.z };
}

export function scale(a: Vec3, s: number): Vec3 {
  return { x: a.x * s, y: a.y * s, z: a.z * s };
}

export function madd(a: Vec3, b: Vec3, s: number): Vec3 {
  return { x: a.x + b.x * s, y: a.y + b.y * s, z: a.z + b.z * s };
}

export function dot(a: Vec3, b: Vec3) {
  return a.x * b.x + a.y * b.y + a.z * b.z;
}

export function cross(a: Vec3, b: Vec3): Vec3 {
  return {
    x: a.y * b.z - a.z * b.y,
    y: a.z * b.x - a.x * b.z,
    z: a.x * b.y - a.y * b.x,
  };
}

export function len(a: Vec3) {
  return Math.hypot(a.x, a.y, a.z);
}

export function len2(a: Vec3) {
  return a.x * a.x + a.y * a.y + a.z * a.z;
}

export function norm(a: Vec3): Vec3 {
  const l = len(a);
  if (l < 1e-8) return { x: 0, y: 1, z: 0 };
  return scale(a, 1 / l);
}

export function clamp(v: number, a: number, b: number) {
  return Math.max(a, Math.min(b, v));
}

export function lerp(a: number, b: number, t: number) {
  return a + (b - a) * t;
}

export function wrapPi(a: number) {
  let x = a;
  while (x > Math.PI) x -= Math.PI * 2;
  while (x < -Math.PI) x += Math.PI * 2;
  return x;
}

export function quatCreate(): Quat {
  return { x: 0, y: 0, z: 0, w: 1 };
}

export function quatSet(o: Quat, x: number, y: number, z: number, w: number) {
  o.x = x;
  o.y = y;
  o.z = z;
  o.w = w;
  return o;
}

export function quatCopy(o: Quat, q: Quat) {
  o.x = q.x;
  o.y = q.y;
  o.z = q.z;
  o.w = q.w;
  return o;
}

export function quatNormalize(q: Quat) {
  const l = Math.hypot(q.x, q.y, q.z, q.w) || 1;
  q.x /= l;
  q.y /= l;
  q.z /= l;
  q.w /= l;
  return q;
}

export function quatFromAxisAngle(axis: Vec3, angle: number): Quat {
  const h = angle * 0.5;
  const s = Math.sin(h);
  const n = norm(axis);
  return quatNormalize({ x: n.x * s, y: n.y * s, z: n.z * s, w: Math.cos(h) });
}

export function quatRotate(q: Quat, v: Vec3): Vec3 {
  const tx = 2 * (q.y * v.z - q.z * v.y);
  const ty = 2 * (q.z * v.x - q.x * v.z);
  const tz = 2 * (q.x * v.y - q.y * v.x);
  return {
    x: v.x + q.w * tx + (q.y * tz - q.z * ty),
    y: v.y + q.w * ty + (q.z * tx - q.x * tz),
    z: v.z + q.w * tz + (q.x * ty - q.y * tx),
  };
}

export function quatInvRotate(q: Quat, v: Vec3): Vec3 {
  const tx = 2 * (-q.y * v.z + q.z * v.y);
  const ty = 2 * (-q.z * v.x + q.x * v.z);
  const tz = 2 * (-q.x * v.y + q.y * v.x);
  return {
    x: v.x + q.w * tx + (-q.y * tz + q.z * ty),
    y: v.y + q.w * ty + (-q.z * tx + q.x * tz),
    z: v.z + q.w * tz + (-q.x * ty + q.y * tx),
  };
}

export function quatIntegrate(q: Quat, omega: Vec3, dt: number) {
  const hx = omega.x * dt * 0.5;
  const hy = omega.y * dt * 0.5;
  const hz = omega.z * dt * 0.5;
  const { x, y, z, w } = q;
  q.w += -hx * x - hy * y - hz * z;
  q.x += hx * w + hy * z - hz * y;
  q.y += hy * w + hz * x - hx * z;
  q.z += hz * w + hx * y - hy * x;
  quatNormalize(q);
}

export function axesOf(q: Quat) {
  const forward = quatRotate(q, { x: 0, y: 0, z: 1 });
  const up = quatRotate(q, { x: 0, y: 1, z: 0 });
  const right = norm(cross(forward, up));
  return { forward, up, right };
}

/** Skill yaw: 0 faces world −Z, +yaw is a left turn under a chase cam. */
export function yawOf(q: Quat) {
  const f = quatRotate(q, { x: 0, y: 0, z: 1 });
  return Math.atan2(-f.x, -f.z);
}

export function quatFromYaw(yaw: number) {
  return quatFromAxisAngle({ x: 0, y: 1, z: 0 }, Math.PI + yaw);
}
