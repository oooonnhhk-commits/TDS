import { defaultUpgrades, resolveCar, CARS } from "./cars";
import { quatFromYaw, quatRotate, yawOf } from "./math";
import { duneHeight, dunes, flatField, rampField, slopeField } from "./terrain";
import { Vehicle } from "./vehicle";

function assert(cond: boolean, msg: string) {
  if (!cond) throw new Error(msg);
}

export function runPhysicsSelfCheck() {
  const q = quatFromYaw(0);
  const f = quatRotate(q, { x: 0, y: 0, z: 1 });
  assert(Math.abs(f.z + 1) < 1e-3 && Math.abs(f.x) < 1e-3, "yaw0 forward " + JSON.stringify(f));
  assert(Math.abs(yawOf(q)) < 1e-3, "yaw extract");

  assert(CARS.some((c) => c.id === "shas06"), "missing shas 2006 vehicle");
  assert(CARS.some((c) => c.id === "lexus05"), "missing Lexus 2005 vehicle");
  assert(CARS.length >= 5, "vehicle roster should contain five selectable cars");
  for (const def of CARS) {
    const resolved = resolveCar(def, defaultUpgrades(def));
    assert(resolved.mass > 1500 && resolved.wheelbase > 2.2, "invalid chassis setup for " + def.id);
    assert(resolved.tireWidth > 0.2 && resolved.travel >= 0.2, "invalid tyre/suspension setup for " + def.id);
    const check = new Vehicle(resolved);
    check.place(0, 0, 0, flatField("asphalt"));
    for (let i = 0; i < 60; i++) check.step(1 / 60, { throttle: 0, brake: 0, steer: 0, handbrake: false }, flatField("asphalt"));
    assert(check.wheels.filter((w) => w.grounded).length === 4, "all tyres should settle for " + def.id);
    assert(Number.isFinite(check.pos.y) && Number.isFinite(check.vel.y), "non-finite chassis state for " + def.id);
  }

  const watad = resolveCar(CARS[0], defaultUpgrades(CARS[0]));
  const flat = flatField("asphalt");
  const sand = flatField("soft");
  const car = new Vehicle(watad);
  car.place(0, 0, 0, flat);
  const y0 = car.pos.y;
  for (let i = 0; i < 120; i++) car.step(1 / 60, { throttle: 0, brake: 0, steer: 0, handbrake: false }, flat);
  assert(Math.abs(car.pos.y - y0) < 0.35, "settled height drift " + car.pos.y);
  assert(Math.abs(car.vel.y) < 1.2, "vertical vel " + car.vel.y);
  assert(car.wheels.filter((w) => w.grounded).length === 4, "not all wheels grounded");

  car.place(0, 0, 0, flat);
  for (let i = 0; i < 180; i++) car.step(1 / 60, { throttle: 1, brake: 0, steer: 0, handbrake: false }, flat);
  const asphaltSpeed = car.speedMs();
  assert(asphaltSpeed > 10, "asphalt speed " + asphaltSpeed.toFixed(2));
  assert(car.pos.z < -5, "moved forward -z " + car.pos.z.toFixed(2));

  const yawBefore = car.telemetry().yaw;
  for (let i = 0; i < 50; i++) car.step(1 / 60, { throttle: 1, brake: 0, steer: 1, handbrake: false }, flat);
  const dyaw = car.telemetry().yaw - yawBefore;
  const w = Math.atan2(Math.sin(dyaw), Math.cos(dyaw));
  assert(w > 0.05, "A/steer+ should increase yaw, got " + w.toFixed(3));

  car.place(0, 0, 0, flat);
  for (let i = 0; i < 40; i++) car.step(1 / 60, { throttle: 1, brake: 0, steer: 0, handbrake: false }, flat);
  const yA = car.telemetry().yaw;
  for (let i = 0; i < 30; i++) car.step(1 / 60, { throttle: 1, brake: 0, steer: -1, handbrake: false }, flat);
  const wD = Math.atan2(Math.sin(car.telemetry().yaw - yA), Math.cos(car.telemetry().yaw - yA));
  assert(wD < -0.04, "D/steer- should decrease yaw, got " + wD.toFixed(3));

  const sandCar = new Vehicle(watad);
  sandCar.drive = "4H";
  sandCar.place(0, 0, 0, sand);
  for (let i = 0; i < 180; i++) sandCar.step(1 / 60, { throttle: 1, brake: 0, steer: 0, handbrake: false }, sand);
  const sandSpeed = Math.abs(sandCar.speedMs());
  assert(sandSpeed < asphaltSpeed * 0.85, "sand slower " + sandSpeed.toFixed(2) + " vs " + asphaltSpeed.toFixed(2));
  assert(sandSpeed > 1.0, "4H vehicle should keep moving on soft sand with stock sand pressure: " + sandSpeed.toFixed(2));
  assert(sandCar.bog < 0.9, "a few seconds of steady 4H driving should not instantly fully bog: " + sandCar.bog.toFixed(2));

  const slope = slopeField(0.42, "hard");
  const low = new Vehicle(watad);
  low.drive = "4L";
  low.place(0, 0, 0, slope);
  const h0 = low.pos.y;
  for (let i = 0; i < 240; i++) low.step(1 / 60, { throttle: 1, brake: 0, steer: 0, handbrake: false }, slope);
  const highGain = low.pos.y - h0;

  const two = new Vehicle(watad);
  two.drive = "2H";
  two.place(0, 0, 0, slope);
  const h1 = two.pos.y;
  for (let i = 0; i < 240; i++) two.step(1 / 60, { throttle: 1, brake: 0, steer: 0, handbrake: false }, slope);
  const twoGain = two.pos.y - h1;
  assert(highGain > twoGain + 0.4, "4L climb " + highGain.toFixed(2) + " vs 2H " + twoGain.toFixed(2));

  const ramp = rampField();
  const jumper = new Vehicle(watad);
  jumper.drive = "4L";
  jumper.place(0, 0, 0, ramp);
  let sawAir = false;
  let sawLanding = false;
  for (let i = 0; i < 720; i++) {
    jumper.step(1 / 60, { throttle: 1, brake: 0, steer: 0, handbrake: false }, ramp);
    sawAir ||= jumper.airborne;
    if (!jumper.airborne && jumper.airborneTime === 0 && sawAir) sawLanding = true;
    assert([jumper.pos.x, jumper.pos.y, jumper.pos.z, jumper.vel.x, jumper.vel.y, jumper.vel.z].every(Number.isFinite), "jump/landing produced a non-finite state");
  }
  assert(sawAir, "4L vehicle should be able to leave the ramp surface");
  assert(sawLanding, "ramp run should return to ground after a jump");

  // Exercise each selected vehicle on the actual generated dune field, including
  // the terrain-relative recovery guard for deep valleys and steep landings.
  let dunePeakSpeed = 0;
  for (const def of CARS) {
    const runner = new Vehicle(resolveCar(def, defaultUpgrades(def)));
    runner.drive = "4L";
    runner.place(0, 0, 0, dunes);
    for (let i = 0; i < 480; i++) {
      const steer = i % 360 < 120 ? 0.1 : i % 360 < 240 ? -0.1 : 0;
      runner.step(1 / 60, { throttle: 1, brake: 0, steer, handbrake: false }, dunes);
      assert(
        [runner.pos.x, runner.pos.y, runner.pos.z, runner.vel.x, runner.vel.y, runner.vel.z].every(Number.isFinite),
        "dune driving produced a non-finite state for " + def.id,
      );
      dunePeakSpeed = Math.max(dunePeakSpeed, Math.abs(runner.speedMs()));
    }
    const groundGap = runner.pos.y - dunes.height(runner.pos.x, runner.pos.z);
    assert(groundGap > -1.5 && groundGap < 16, "dune chassis/terrain separation for " + def.id + ": " + groundGap.toFixed(2));
    assert(Math.abs(runner.pos.x) + Math.abs(runner.pos.z) > 3, "dune vehicle failed to travel for " + def.id);
  }

  const peak = duneHeight(0, -205);
  const camp = duneHeight(0, 42);
  assert(peak > camp + 12, "peak taller than camp " + peak.toFixed(1) + " / " + camp.toFixed(1));

  return {
    asphaltSpeed: +(asphaltSpeed * 3.6).toFixed(1),
    sandSpeed: +(Math.abs(sandCar.speedMs()) * 3.6).toFixed(1),
    yawLeft: +w.toFixed(3),
    climb4L: +highGain.toFixed(2),
    climb2H: +twoGain.toFixed(2),
    jumpDistance: +jumper.bestJump.toFixed(2),
    dunePeakSpeed: +(dunePeakSpeed * 3.6).toFixed(1),
    peak: +peak.toFixed(1),
    camp: +camp.toFixed(1),
  };
}
