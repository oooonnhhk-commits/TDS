import { clamp, type Vec3 } from "./math";

export type SurfaceKind = "soft" | "medium" | "hard" | "rock" | "asphalt";

export type Surface = {
  kind: SurfaceKind;
  mu: number;
  crr: number;
  sink: number;
  rumble: number;
};

export interface TerrainField {
  height(x: number, z: number): number;
  normal(x: number, z: number): Vec3;
  surface(x: number, z: number): Surface;
}

const SURFACE: Record<SurfaceKind, Surface> = {
  soft: { kind: "soft", mu: 0.4, crr: 0.16, sink: 1, rumble: 0.15 },
  medium: { kind: "medium", mu: 0.58, crr: 0.07, sink: 0.45, rumble: 0.08 },
  hard: { kind: "hard", mu: 0.74, crr: 0.04, sink: 0.12, rumble: 0.05 },
  rock: { kind: "rock", mu: 0.82, crr: 0.05, sink: 0, rumble: 1 },
  asphalt: { kind: "asphalt", mu: 1.12, crr: 0.014, sink: 0, rumble: 0 },
};

function hash2(ix: number, iz: number) {
  let n = Math.imul(ix, 374761393) + Math.imul(iz, 668265263);
  n = Math.imul(n ^ (n >>> 13), 1274126177);
  return ((n ^ (n >>> 16)) >>> 0) / 4294967295;
}

function noise(x: number, z: number) {
  const x0 = Math.floor(x);
  const z0 = Math.floor(z);
  const fx = x - x0;
  const fz = z - z0;
  const sx = fx * fx * (3 - 2 * fx);
  const sz = fz * fz * (3 - 2 * fz);
  const n00 = hash2(x0, z0);
  const n10 = hash2(x0 + 1, z0);
  const n01 = hash2(x0, z0 + 1);
  const n11 = hash2(x0 + 1, z0 + 1);
  return n00 * (1 - sx) * (1 - sz) + n10 * sx * (1 - sz) + n01 * (1 - sx) * sz + n11 * sx * sz;
}

function blob(x: number, z: number, cx: number, cz: number, rx: number, rz: number, amp: number) {
  const dx = (x - cx) / rx;
  const dz = (z - cz) / rz;
  const r2 = dx * dx + dz * dz;
  if (r2 > 2.4) return 0;
  return amp * Math.exp(-r2 * 1.85);
}

function smoothstep(e0: number, e1: number, x: number) {
  const t = clamp((x - e0) / (e1 - e0), 0, 1);
  return t * t * (3 - 2 * t);
}

/** Packed service road wandering the east valley. */
export function roadCenterX(z: number) {
  return 78 + Math.sin(z * 0.011) * 26 + Math.sin(z * 0.004 + 1.2) * 10;
}

export function onRoad(x: number, z: number) {
  if (z < -90 || z > 300) return 0;
  const d = Math.abs(x - roadCenterX(z));
  return 1 - smoothstep(6.5, 13, d);
}

function rawDunes(x: number, z: number) {
  const warp = Math.sin(x * 0.0065) * 1.15 + Math.sin(z * 0.004) * 0.4;
  let h = 0;
  h += Math.sin(z * 0.02 + warp) * 13.5;
  h += Math.sin(z * 0.049 + x * 0.012 + 1.4) * 5.2;
  h += Math.sin(x * 0.016 + z * 0.0055) * 3.4;
  h += Math.sin(x * 0.041 + z * 0.02 + 0.6) * 1.15;
  h += (noise(x * 0.018, z * 0.018) - 0.5) * 5.2;
  h += (noise(x * 0.007 + 9, z * 0.007 - 4) - 0.5) * 7.5;
  h += blob(x, z, 0, -205, 52, 64, 32);
  h += blob(x, z, 150, -30, 58, 46, 20);
  h += blob(x, z, -175, 70, 72, 60, 24);
  h += blob(x, z, 30, 230, 80, 48, 16);
  h += blob(x, z, -60, -40, 34, 28, 9);
  h += blob(x, z, 210, 150, 40, 36, 14);
  const ax = Math.max(0, Math.abs(x) - 390);
  const az = Math.max(0, Math.abs(z) - 390);
  h += (ax * ax + az * az) * 0.018;
  return h;
}

export function duneHeight(x: number, z: number) {
  let h = rawDunes(x, z);
  const camp = Math.exp(-(x * x + (z - 42) * (z - 42)) / (2 * 34 * 34));
  h = h * (1 - camp * 0.9) + 3.2 * camp * 0.9;
  const run = Math.exp(-(x * x) / (2 * 22 * 22) - (z + 95) * (z + 95) / (2 * 18 * 18));
  h = h * (1 - run * 0.55) + (rawDunes(0, -95) * 0.35 + 6) * run * 0.55;
  const road = onRoad(x, z);
  if (road > 0) {
    const grade = 3.1 + Math.sin(z * 0.007) * 0.8;
    h = h * (1 - road * 0.94) + grade * road * 0.94;
  }
  return h;
}

export function duneNormal(x: number, z: number): Vec3 {
  const e = 0.85;
  const hyx = duneHeight(x + e, z) - duneHeight(x - e, z);
  const hyz = duneHeight(x, z + e) - duneHeight(x, z - e);
  const nx = -hyx;
  const ny = e * 2;
  const nz = -hyz;
  const l = Math.hypot(nx, ny, nz) || 1;
  return { x: nx / l, y: ny / l, z: nz / l };
}

export function duneSurface(x: number, z: number): Surface {
  if (onRoad(x, z) > 0.65) return SURFACE.asphalt;
  const e = 1.4;
  const h = duneHeight(x, z);
  const hx = duneHeight(x + e, z) - duneHeight(x - e, z);
  const hz = duneHeight(x, z + e) - duneHeight(x, z - e);
  const slope = Math.hypot(hx, hz) / (e * 2);
  const n = noise(x * 0.03 + 3, z * 0.03 - 2);
  const bowl = noise(x * 0.012, z * 0.012);
  if (slope > 0.62 && n > 0.62) return SURFACE.rock;
  if (slope < 0.18 && bowl < 0.38 && h < 8) return SURFACE.soft;
  if (slope > 0.34 || h > 16) return SURFACE.hard;
  if (bowl < 0.46) return SURFACE.soft;
  return SURFACE.medium;
}

export const WORLD_HALF = 460;

export const dunes: TerrainField = {
  height: duneHeight,
  normal: duneNormal,
  surface: duneSurface,
};

export const CAMP = { x: 0, z: 42 };
export const CLIMB_PEAK = { x: 0, z: -205 };
export const CLIMB_START = { x: 0, z: -95 };

export function flatField(kind: SurfaceKind = "asphalt"): TerrainField {
  const s = SURFACE[kind];
  return {
    height: () => 0,
    normal: () => ({ x: 0, y: 1, z: 0 }),
    surface: () => s,
  };
}

/** Constant grade. Forward (−Z) climbs when grade > 0. */
export function slopeField(grade: number, kind: SurfaceKind): TerrainField {
  const s = SURFACE[kind];
  return {
    height: (_x, z) => -grade * z,
    normal: () => {
      const nx = 0;
      const ny = 1;
      const nz = grade;
      const l = Math.hypot(nx, ny, nz);
      return { x: nx / l, y: ny / l, z: nz / l };
    },
    surface: () => s,
  };
}

export function rampField(): TerrainField {
  return {
    height: (x, z) => {
      const edge = -8;
      const lip = -18;
      if (z > edge) return 0;
      if (z > lip) {
        const t = (edge - z) / (edge - lip);
        return t * t * 7.5;
      }
      return 7.5;
    },
    normal: (x, z) => {
      const e = 0.2;
      const h = (zz: number) => rampField().height(x, zz);
      const hyz = h(z + e) - h(z - e);
      const nz = -hyz;
      const ny = e * 2;
      const l = Math.hypot(nz, ny) || 1;
      return { x: 0, y: ny / l, z: nz / l };
    },
    surface: () => SURFACE.hard,
  };
}
