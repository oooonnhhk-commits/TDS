import type { DriveMode, ResolvedCar } from "./cars";
import {
  add,
  axesOf,
  clamp,
  cross,
  dot,
  len,
  madd,
  norm,
  quatCopy,
  quatCreate,
  quatFromYaw,
  quatIntegrate,
  quatInvRotate,
  quatRotate,
  scale,
  sub,
  vcopy,
  yawOf,
  type Quat,
  type Vec3,
} from "./math";
import type { Surface, TerrainField } from "./terrain";

const G = 9.81;
const TAU = Math.PI * 2;

export type DriveInput = {
  throttle: number;
  brake: number;
  steer: number;
  handbrake: boolean;
};

export type WheelState = {
  x: number;
  z: number;
  rear: boolean;
  steer: boolean;
  omega: number;
  compression: number;
  grounded: boolean;
  spin: number;
  slip: number;
  load: number;
  suspLen: number;
  contact: Vec3;
  normal: Vec3;
};

export type VehicleTelemetry = {
  speed: number;
  speedMs: number;
  rpm: number;
  gear: number;
  drive: DriveMode;
  airborne: boolean;
  bog: number;
  surface: Surface["kind"];
  yaw: number;
  damage: number;
  wheelSpin: number;
  slip: number;
  grounded: number;
};

const ZERO_INPUT: DriveInput = { throttle: 0, brake: 0, steer: 0, handbrake: false };

export class Vehicle {
  pos: Vec3 = { x: 0, y: 2, z: 0 };
  vel: Vec3 = { x: 0, y: 0, z: 0 };
  angVel: Vec3 = { x: 0, y: 0, z: 0 };
  quat: Quat = quatCreate();
  wheels: WheelState[];
  gear = 1;
  rpm = 800;
  drive: DriveMode = "4H";
  bog = 0;
  airborne = false;
  airborneTime = 0;
  shiftCd = 0;
  damage = { engine: 1, body: 1, susp: 1, tires: [1, 1, 1, 1] };
  jumpOrigin: Vec3 | null = null;
  bestJump = 0;
  odometer = 0;
  sandMeters = 0;
  driftScore = 0;
  surface: Surface["kind"] = "medium";
  wheelSpin = 0;
  slipAmount = 0;
  impact = 0;
  prevGrounded = false;
  scratch = 0;
  debugForce = 0;
  debugPen = 0;
  debugJ = { x: 0, y: 0, z: 0 };
  steerVisual = 0;
  car: ResolvedCar;
  invI = { x: 1, y: 1, z: 1 };
  ai = false;
  stuck = 0;
  reversing = 0;
  horn = 0;

  constructor(car: ResolvedCar) {
    this.car = car;
    const hb = car.wheelbase * 0.5;
    const ht = car.track * 0.5;
    this.wheels = [
      wheel(ht, hb, false),
      wheel(-ht, hb, false),
      wheel(ht, -hb, true),
      wheel(-ht, -hb, true),
    ];
    this.recomputeInertia();
    this.quat = quatFromYaw(0);
  }

  recomputeInertia() {
    const m = this.car.mass;
    const w = this.car.track;
    const l = this.car.wheelbase;
    const h = this.car.cgHeight;
    const pitch = m * (h * h + l * l) / 11;
    const yaw = m * (w * w + l * l) / 11;
    const roll = m * (h * h + w * w) / 11;
    this.invI = { x: 1 / pitch, y: 1 / yaw, z: 1 / roll };
  }

  setCar(car: ResolvedCar) {
    const q = quatCopy(quatCreate(), this.quat);
    const p = { ...this.pos };
    const drive = this.drive;
    const dmg = this.damage;
    this.car = car;
    this.recomputeInertia();
    const hb = car.wheelbase * 0.5;
    const ht = car.track * 0.5;
    this.wheels[0].x = ht;
    this.wheels[0].z = hb;
    this.wheels[1].x = -ht;
    this.wheels[1].z = hb;
    this.wheels[2].x = ht;
    this.wheels[2].z = -hb;
    this.wheels[3].x = -ht;
    this.wheels[3].z = -hb;
    quatCopy(this.quat, q);
    vcopy(this.pos, p);
    this.drive = drive;
    this.damage = dmg;
  }

  place(x: number, z: number, yaw: number, field: TerrainField) {
    this.vel = { x: 0, y: 0, z: 0 };
    this.angVel = { x: 0, y: 0, z: 0 };
    this.quat = quatFromYaw(yaw);
    this.gear = 1;
    this.rpm = this.car.idle;
    this.bog = 0;
    this.airborne = false;
    this.airborneTime = 0;
    this.jumpOrigin = null;
    this.shiftCd = 0;
    this.stuck = 0;
    this.reversing = 0;
    for (const w of this.wheels) {
      w.omega = 0;
      w.compression = 0.1;
      w.grounded = false;
      w.spin = 0;
      w.slip = 0;
    }
    const ground = field.height(x, z);
    const mountY = -0.18;
    this.pos = {
      x,
      y: ground - mountY + (this.car.restLength - 0.1) + this.car.tireRadius,
      z,
    };
    for (let i = 0; i < 20; i++) this.substep(1 / 60, ZERO_INPUT, field);
    this.vel = { x: 0, y: 0, z: 0 };
    this.angVel = { x: 0, y: 0, z: 0 };
  }

  repair() {
    this.damage = { engine: 1, body: 1, susp: 1, tires: [1, 1, 1, 1] };
  }

  tryDrive(mode: DriveMode) {
    if (mode === "4L" && Math.abs(this.speedMs()) > 11) return false;
    this.drive = mode;
    return true;
  }

  speedMs() {
    const f = axesOf(this.quat).forward;
    return dot(this.vel, f);
  }

  telemetry(): VehicleTelemetry {
    const spins = this.wheels.reduce((s, w) => s + w.spin, 0) / 4;
    return {
      speed: Math.abs(this.speedMs()) * 3.6,
      speedMs: this.speedMs(),
      rpm: this.rpm,
      gear: this.gear,
      drive: this.drive,
      airborne: this.airborne,
      bog: this.bog,
      surface: this.surface,
      yaw: yawOf(this.quat),
      damage: 1 - (this.damage.engine + this.damage.body + this.damage.susp + avg(this.damage.tires)) / 4,
      wheelSpin: spins,
      slip: this.slipAmount,
      grounded: this.wheels.filter((w) => w.grounded).length,
    };
  }

  step(dt: number, input: DriveInput, field: TerrainField) {
    // Three semi-fixed substeps reduce suspension tunnelling and improve landings
    // without adding a heavyweight rigid-body dependency to mobile browsers.
    const steps = 3;
    const h = dt / steps;
    this.debugForce = 0;
    this.debugJ.x = 0;
    this.debugJ.y = 0;
    this.debugJ.z = 0;
    for (let i = 0; i < steps; i++) this.substep(h, input, field);
  }

  private substep(dt: number, input: DriveInput, field: TerrainField) {
    const car = this.car;
    this.shiftCd = Math.max(0, this.shiftCd - dt);
    this.horn = Math.max(0, this.horn - dt);
    this.impact = Math.max(0, this.impact - dt * 2.5);

    let throttle = clamp(input.throttle, 0, 1);
    let brake = clamp(input.brake, 0, 1);
    const steer = clamp(input.steer, -1, 1);
    const handbrake = input.handbrake;

    const speed = this.speedMs();
    if (brake > 0.55 && throttle < 0.08 && speed > -0.6 && speed < 1.1) {
      this.reversing = 0.2;
    }
    if (this.reversing > 0 && brake > 0.2 && throttle < 0.08) {
      this.reversing = 0.2;
      throttle = brake;
      brake = 0;
      this.gear = -1;
    } else {
      this.reversing = Math.max(0, this.reversing - dt);
      if (this.gear < 0 && speed > 0.4) this.gear = 1;
      if (this.gear < 0 && throttle < 0.05 && brake < 0.05) this.gear = 1;
    }

    this.rpm = this.solveRpm(throttle);
    this.autoShift(throttle);

    this.vel.y -= G * dt;
    const horiz = Math.hypot(this.vel.x, this.vel.z);
    if (horiz > 0.05) {
      const drag = 0.5 * 1.15 * car.cdA * horiz * horiz;
      const decel = Math.min(horiz, (drag / car.mass) * dt);
      this.vel.x -= (this.vel.x / horiz) * decel;
      this.vel.z -= (this.vel.z / horiz) * decel;
    }

    const { forward, up, right } = axesOf(this.quat);
    const mounts = this.wheels.map((w) => this.wheelMount(w, forward, up, right));
    let groundCount = 0;
    let surfaceVote: Surface["kind"] = this.surface;
    let loadSum = 0;

    for (let i = 0; i < this.wheels.length; i++) {
      const w = this.wheels[i];
      const mount = mounts[i];
      const hit = raycast(mount, scale(up, -1), car.restLength + car.tireRadius + 0.15, field)
        ?? raycast(mount, { x: 0, y: -1, z: 0 }, car.restLength + car.travel + car.tireRadius + 0.3, field);
      w.grounded = false;
      w.load = 0;
      if (!hit) {
        w.compression = Math.max(0, w.compression - dt * 2);
        w.suspLen = Math.min(car.restLength + car.travel, w.suspLen + dt * 1.5);
        w.omega *= Math.exp(-0.6 * dt);
        continue;
      }
      if (hit.dist < car.tireRadius * 0.35) {
        const push = (car.tireRadius * 0.35 - hit.dist) * 0.5;
        this.pos = madd(this.pos, hit.normal, push);
        const into = dot(this.vel, hit.normal);
        if (into < 0) {
          this.vel = madd(this.vel, hit.normal, -into * 0.8);
        }
      }
      const suspLen = Math.max(0.02, hit.dist - car.tireRadius);
      w.suspLen = suspLen;
      const compression = car.restLength - suspLen;
      if (compression <= 0) {
        w.compression = 0;
        w.omega *= Math.exp(-0.4 * dt);
        continue;
      }
      const compVel = clamp((compression - w.compression) / dt, -12, 12);
      w.compression = compression;
      const dampScale = 0.55 + 0.45 * this.damage.susp;
      let force = car.spring * Math.min(compression, car.travel) * dampScale + car.damper * dampScale * compVel;
      if (compression > car.travel) {
        force += (compression - car.travel) * car.spring * 3.2;
        if (compVel > 8) this.bumpDamage(compVel * 0.7);
      }
      force = clamp(force, 0, car.mass * G * 1.85);
      w.load = force;
      w.suspLen = suspLen;
      w.contact = hit.point;
      w.normal = hit.normal;
      w.grounded = true;
      groundCount++;
      loadSum += force;
      this.applyImpulse(hit.point, scale(hit.normal, force * dt));
      const surf = field.surface(hit.point.x, hit.point.z);
      if (w.rear) surfaceVote = surf.kind;
    }

    // A simple axle anti-roll bar transfers load between left and right wheels.
    // It keeps tall 4x4s from feeling like a flat plank while limiting artificial roll.
    for (const rearAxle of [false, true]) {
      const pair = this.wheels.filter((w) => w.rear === rearAxle && w.grounded);
      if (pair.length !== 2) continue;
      const delta = pair[0].compression - pair[1].compression;
      const raw = delta * car.mass * G * 0.2;
      const correction = clamp(raw, -Math.min(pair[1].load * 0.32, car.mass * G * 0.12), Math.min(pair[0].load * 0.32, car.mass * G * 0.12));
      if (Math.abs(correction) < 1) continue;
      pair[0].load -= correction;
      pair[1].load += correction;
      this.applyImpulse(pair[0].contact, scale(pair[0].normal, -correction * dt));
      this.applyImpulse(pair[1].contact, scale(pair[1].normal, correction * dt));
    }

    const wasAir = this.airborne;
    this.airborne = groundCount === 0;
    if (this.airborne) {
      this.airborneTime += dt;
      if (!this.jumpOrigin) this.jumpOrigin = { ...this.pos };
      const air = 1.35 * (1 - Math.exp(-dt * 2));
      this.angVel.y += steer * 1.15 * dt;
      this.angVel = add(this.angVel, scale(right, (brake - throttle) * 0.55 * dt));
      this.angVel = add(this.angVel, scale(forward, -steer * 0.85 * dt));
      for (const w of this.wheels) w.omega *= Math.exp(-0.15 * dt);
      this.bog = Math.max(0, this.bog - dt * 0.5);
    } else {
      if (wasAir && this.jumpOrigin) {
        const dx = this.pos.x - this.jumpOrigin.x;
        const dz = this.pos.z - this.jumpOrigin.z;
        const d = Math.hypot(dx, dz);
        if (d > this.bestJump && this.airborneTime > 0.18) this.bestJump = d;
        const slam = Math.max(0, -this.vel.y);
        if (slam > 5) {
          this.impact = Math.min(1, slam / 18);
          this.bumpDamage(slam * 0.7);
        }
      }
      this.jumpOrigin = null;
      this.airborneTime = 0;
      this.applyTires(dt, throttle, brake, steer, handbrake, forward, up, right, field);
    }
    // The chassis must still collide with the dune if all four tyres lose contact,
    // for example during a roll or a steep landing.
    this.belly(field, forward, up, right);

    this.surface = surfaceVote;
    this.prevGrounded = groundCount > 0;

    if (!this.airborne && groundCount >= 2 && up.y > 0.4) {
      let nx = 0;
      let ny = 0;
      let nz = 0;
      let c = 0;
      for (const w of this.wheels) {
        if (!w.grounded) continue;
        nx += w.normal.x;
        ny += w.normal.y;
        nz += w.normal.z;
        c++;
      }
      const target = norm({ x: nx / c, y: ny / c, z: nz / c });
      const align = cross(up, target);
      const hold = clamp((up.y - 0.35) / 0.65, 0, 1) * (0.65 + 0.35 * this.car.stability);
      this.angVel = madd(this.angVel, align, 9 * hold * dt);
    }

    const bodyDamp = this.airborne ? 0.15 : 1.35;
    this.angVel = scale(this.angVel, Math.exp(-bodyDamp * dt));
    const cap = 9;
    const am = len(this.angVel);
    if (am > cap) this.angVel = scale(this.angVel, cap / am);

    this.pos = madd(this.pos, this.vel, dt);
    quatIntegrate(this.quat, this.angVel, dt);

    const sm = Math.abs(this.speedMs());
    this.odometer += sm * dt;
    if (!this.airborne && this.surface !== "asphalt" && this.surface !== "rock") this.sandMeters += sm * dt;
    if (handbrake && sm > 4) this.driftScore += this.slipAmount * sm * dt * 2.2;

    if (sm < 1.2 && throttle > 0.7 && this.bog > 0.45) this.stuck += dt;
    else this.stuck = Math.max(0, this.stuck - dt * 0.5);

    const spd = len(this.vel);
    if (spd > 85) this.vel = scale(this.vel, 85 / spd);
    // Recovery is relative to the local terrain elevation, not sea level: dune
    // valleys may be below -30 m and should not cause a recursive reset loop.
    const recoveryX = Number.isFinite(this.pos.x) ? this.pos.x : 0;
    const recoveryZ = Number.isFinite(this.pos.z) ? this.pos.z : 0;
    const localGround = field.height(recoveryX, recoveryZ);
    const localGroundSafe = Number.isFinite(localGround) ? localGround : 0;
    const yIsInvalid = !Number.isFinite(this.pos.y)
      || this.pos.y < localGroundSafe - 16
      || this.pos.y > localGroundSafe + 180;
    const positionIsInvalid = !Number.isFinite(this.pos.x) || !Number.isFinite(this.pos.z) || yIsInvalid;
    if (positionIsInvalid) {
      // Recover in-place rather than calling place() from inside a physics substep.
      // Calling place() here re-enters the same substep and can recurse forever on
      // steep/out-of-range terrain.
      const recoveredYaw = yawOf(this.quat);
      this.pos = {
        x: recoveryX,
        y: localGroundSafe + car.restLength + car.tireRadius + 0.08,
        z: recoveryZ,
      };
      this.vel = { x: 0, y: 0, z: 0 };
      this.angVel = { x: 0, y: 0, z: 0 };
      this.quat = quatFromYaw(Number.isFinite(recoveredYaw) ? recoveredYaw : 0);
      this.bog = 0;
      this.airborne = false;
      this.airborneTime = 0;
      this.jumpOrigin = null;
      for (const wheel of this.wheels) {
        wheel.omega = 0;
        wheel.compression = 0.1;
        wheel.suspLen = car.restLength;
        wheel.grounded = false;
        wheel.spin = 0;
        wheel.slip = 0;
      }
    }

    const maxSteer = car.maxSteer / (1 + sm * 0.045);
    const targetSteer = steer * maxSteer * (this.gear < 0 ? 1 : 1);
    this.steerVisual += (targetSteer - this.steerVisual) * Math.min(1, dt * 10);
  }

  private applyTires(
    dt: number,
    throttle: number,
    brake: number,
    steer: number,
    handbrake: boolean,
    forward: Vec3,
    up: Vec3,
    right: Vec3,
    field: TerrainField,
  ) {
    const car = this.car;
    const speed = this.speedMs();
    const sm = Math.abs(speed);
    const maxSteer = car.maxSteer / (1 + sm * 0.045);
    const steerAngle = steer * maxSteer;
    const low = this.drive === "4L" ? car.lowRatio : 1;
    const ratio = Math.abs(this.gearRatio()) * car.finalDrive * low;
    const engineT = this.engineTorque(this.rpm) * this.damage.engine * (0.55 + 0.45 * this.damage.body);
    let driveTorque = throttle * engineT * ratio * 0.9;
    if (this.gear < 0) driveTorque = -Math.abs(driveTorque);
    const top = this.topSpeed();
    if (sm > top) driveTorque = 0;
    if (throttle < 0.12 && this.gear > 0) {
      driveTorque -= Math.sign(speed || 1) * engineT * 0.18 * ratio;
    }

    const drivenIdx = this.wheels.map((w, i) => (this.isDriven(w) ? i : -1)).filter((i) => i >= 0);
    const per = drivenIdx.length ? driveTorque / drivenIdx.length : 0;
    const lock = this.drive === "4L" ? 0.82 : this.drive === "4H" ? 0.38 : 0.08;

    const asks = this.wheels.map(() => 0);
    for (const i of drivenIdx) asks[i] = per;

    for (const axle of [false, true]) {
      const idx = this.wheels.map((w, i) => (w.rear === axle && this.isDriven(w) ? i : -1)).filter((i) => i >= 0);
      if (idx.length < 2) continue;
      const caps = idx.map((i) => this.wheelGripCap(i, field) * car.tireRadius);
      let spare = 0;
      for (let k = 0; k < idx.length; k++) {
        if (asks[idx[k]] > caps[k]) {
          spare += (asks[idx[k]] - caps[k]) * lock;
          asks[idx[k]] = caps[k] + (asks[idx[k]] - caps[k]) * (1 - lock);
        }
      }
      for (let k = 0; k < idx.length && spare > 0; k++) {
        const room = Math.max(0, caps[k] * 1.05 - asks[idx[k]]);
        const give = Math.min(room, spare);
        asks[idx[k]] += give;
        spare -= give;
      }
    }

    let slipAcc = 0;
    let spinAcc = 0;
    let nSlip = 0;

    for (let i = 0; i < this.wheels.length; i++) {
      const w = this.wheels[i];
      if (!w.grounded) continue;
      const steered = w.steer ? steerAngle : 0;
      const wheelFwd = norm(madd(scale(forward, Math.cos(steered)), right, -Math.sin(steered)));
      const wheelRight = norm(cross(wheelFwd, w.normal.y > 0.2 ? w.normal : up));
      const r = sub(w.contact, this.pos);
      const vPoint = add(this.vel, cross(this.angVel, r));
      const vLat = dot(vPoint, wheelRight);
      const vLong = dot(vPoint, wheelFwd);
      const surf = field.surface(w.contact.x, w.contact.z);
      let mu = this.muFor(surf) * (0.45 + 0.55 * this.damage.tires[i]);
      if (handbrake && w.rear) mu *= 0.32;
      if (this.bog > 0) mu *= 1 - this.bog * 0.42 * surf.sink;
      const nImp = w.load * dt;
      const maxImp = mu * nImp * 1.05;

      const invLat = Math.max(1 / car.mass, this.invMass(r, wheelRight));
      const relax = 1 - Math.exp(-dt * (22 + mu * 28) * (handbrake && w.rear ? 0.35 : 1));
      let latImp = (-vLat / invLat) * relax;
      latImp = clamp(latImp, -maxImp, maxImp);
      this.applyImpulse(w.contact, scale(wheelRight, latImp));

      const rem = Math.sqrt(Math.max(0, maxImp * maxImp - latImp * latImp));
      const tAsk = asks[i];
      let longForce = tAsk / Math.max(0.18, car.tireRadius);
      const crr = surf.crr * (0.85 + car.pressure * 0.25);
      longForce -= Math.sign(vLong || w.omega || 1) * crr * w.load;
      const brakeT = brake * car.brake * (handbrake && w.rear ? 1.35 : 0.55) * (w.rear ? 0.85 : 1);
      longForce -= Math.sign(vLong || w.omega || 1) * (brakeT / Math.max(0.2, car.tireRadius));
      let longImp = longForce * dt;
      longImp = clamp(longImp, -rem, rem);
      this.applyImpulse(w.contact, scale(wheelFwd, longImp));
      this.debugForce += longImp / dt;

      const patch = vLong / Math.max(0.25, car.tireRadius);
      const gripT = mu * Math.max(200, w.load) * car.tireRadius;
      const over = Math.max(0, Math.abs(tAsk) - gripT);
      w.slip = Math.abs(vLat) / Math.max(3, sm);
      if (over > 30 && Math.abs(throttle) > 0.15) {
        w.spin = clamp(over / gripT, 0, 2);
        w.omega += Math.sign(tAsk || 1) * (over / 1.35) * dt;
      } else {
        w.spin *= 0.85;
        w.omega += (patch - w.omega) * Math.min(1, dt * 16);
      }
      w.omega = clamp(w.omega, -160, 160);
      slipAcc += w.slip;
      spinAcc += w.spin;
      nSlip++;

      if (surf.sink > 0.2 && sm < 10) {
        // Deep sand should punish high tyre pressure and sustained wheelspin,
        // but a sensible 4x4 setup must not bog almost instantly on flat sand.
        const pressureLoad = lerp(0.62, 1.42, (car.pressure - 0.72) / 0.56);
        const footprint = clamp(car.tireWidth / 0.285, 0.82, 1.35);
        const lowSpeed = Math.exp(-sm / 5.8);
        const wheelSpinStress = 0.72 + Math.min(1.2, w.spin) * 0.32;
        const dig = surf.sink * (0.05 + throttle * 0.18) * lowSpeed * pressureLoad * wheelSpinStress / footprint;
        this.bog = clamp(this.bog + dig * dt * 0.25 * (this.drive === "4L" ? 0.62 : 1), 0, 1);
      }
    }

    const horizontalSpeed = Math.hypot(this.vel.x, this.vel.z);
    const tyresHaveTraction = horizontalSpeed > 3 && this.wheelSpin < 0.32;
    if (!this.airborne && (this.surface !== "soft" || tyresHaveTraction || throttle < 0.08)) {
      const recovery = throttle < 0.08 ? 0.72 : this.drive === "4L" ? 0.58 : 0.34;
      this.bog = clamp(this.bog - dt * recovery, 0, 1);
    }
    if (this.bog > 0.05) {
      const hspd = Math.hypot(this.vel.x, this.vel.z);
      const drag = this.bog * car.mass * (this.drive === "4L" ? 0.7 : 1.25);
      const decel = Math.min(hspd, (drag / car.mass) * dt);
      if (hspd > 0.01) {
        this.vel.x -= (this.vel.x / hspd) * decel;
        this.vel.z -= (this.vel.z / hspd) * decel;
      }
    }

    this.slipAmount = nSlip ? slipAcc / nSlip : 0;
    this.wheelSpin = nSlip ? spinAcc / nSlip : 0;

    if (this.drive === "4L" || this.drive === "4H") {
      for (const axle of [false, true]) {
        const pair = this.wheels.filter((w) => w.rear === axle && w.grounded);
        if (pair.length < 2) continue;
        const avgW = (pair[0].omega + pair[1].omega) / 2;
        const blend = this.drive === "4L" ? 0.45 : 0.16;
        pair[0].omega += (avgW - pair[0].omega) * blend;
        pair[1].omega += (avgW - pair[1].omega) * blend;
      }
    }
  }

  private wheelGripCap(i: number, field: TerrainField) {
    const w = this.wheels[i];
    if (!w.grounded) return 0;
    const surf = field.surface(w.contact.x, w.contact.z);
    const mu = this.muFor(surf) * (0.45 + 0.55 * this.damage.tires[i]);
    return mu * Math.max(200, w.load) * 0.92;
  }

  private muFor(surf: Surface) {
    const car = this.car;
    let mu = surf.mu * car.grip * car.sandBias ** (surf.kind === "asphalt" ? 0 : 0.35);
    const pressure = clamp((car.pressure - 0.72) / 0.56, 0, 1);
    if (surf.kind === "soft" || surf.kind === "medium") {
      // Lower pressure increases the footprint and improves flotation on sand.
      mu *= lerp(1.2, 0.82, pressure);
    } else {
      mu *= lerp(0.92, 1.05, pressure);
    }
    if (this.drive === "2H" && (surf.kind === "soft" || surf.kind === "medium")) mu *= 0.9;
    if (this.drive === "4L" && surf.kind !== "asphalt") mu *= 1.06;
    return mu;
  }

  private belly(field: TerrainField, forward: Vec3, up: Vec3, right: Vec3) {
    const points = [
      { x: 0, z: this.car.wheelbase * 0.42 },
      { x: 0, z: -this.car.wheelbase * 0.48 },
      { x: this.car.track * 0.42, z: 0 },
      { x: -this.car.track * 0.42, z: 0 },
    ];
    for (const p of points) {
      const world = add(this.pos, add(scale(right, p.x), add(scale(forward, p.z), scale(up, -0.34))));
      const h = field.height(world.x, world.z);
      if (world.y < h + 0.12) {
        const pen = h + 0.12 - world.y;
        this.debugPen = Math.max(this.debugPen, pen);
        const n = field.normal(world.x, world.z);
        this.pos = madd(this.pos, n, pen * 0.65);
        const vn = dot(this.vel, n);
        if (vn < 0) {
          this.vel = madd(this.vel, n, -vn * 0.85);
          if (-vn > 7) this.bumpDamage(-vn * 0.45);
        }
        this.vel.x *= 0.992;
        this.vel.z *= 0.992;
      }
    }
  }

  private bumpDamage(severity: number) {
    const d = clamp((severity - 5) * 0.012, 0, 0.08);
    if (d <= 0) return;
    this.damage.engine = clamp(this.damage.engine - d * 0.65, 0.45, 1);
    this.damage.body = clamp(this.damage.body - d, 0.4, 1);
    this.damage.susp = clamp(this.damage.susp - d * 0.8, 0.4, 1);
    for (let i = 0; i < 4; i++) this.damage.tires[i] = clamp(this.damage.tires[i] - d * 0.4, 0.35, 1);
    this.impact = Math.min(1, this.impact + d * 4);
  }

  private applyImpulse(point: Vec3, impulse: Vec3) {
    const m = this.car.mass;
    this.vel.x += impulse.x / m;
    this.vel.y += impulse.y / m;
    this.vel.z += impulse.z / m;
    this.debugJ.x += impulse.x;
    this.debugJ.y += impulse.y;
    this.debugJ.z += impulse.z;
    const r = sub(point, this.pos);
    const ang = cross(r, impulse);
    const body = quatInvRotate(this.quat, ang);
    const dw = quatRotate(this.quat, {
      x: body.x * this.invI.x,
      y: body.y * this.invI.y,
      z: body.z * this.invI.z,
    });
    this.angVel.x += dw.x;
    this.angVel.y += dw.y;
    this.angVel.z += dw.z;
  }

  private invMass(r: Vec3, dir: Vec3) {
    const rxn = cross(r, dir);
    const b = quatInvRotate(this.quat, rxn);
    const iw = quatRotate(this.quat, { x: b.x * this.invI.x, y: b.y * this.invI.y, z: b.z * this.invI.z });
    return 1 / this.car.mass + dot(cross(iw, r), dir);
  }

  private wheelMount(w: WheelState, forward: Vec3, up: Vec3, right: Vec3) {
    return add(this.pos, add(scale(right, w.x), add(scale(up, -0.18), scale(forward, w.z))));
  }

  private isDriven(w: WheelState) {
    if (this.drive === "2H") return w.rear;
    return true;
  }

  private gearRatio() {
    if (this.gear < 0) return -3.4;
    const idx = clamp(this.gear, 1, this.car.gears.length) - 1;
    return this.car.gears[idx];
  }

  private engineTorque(rpm: number) {
    const x = clamp(rpm / this.car.redline, 0, 1.05);
    const shape = Math.sin(Math.min(1, x) * Math.PI * 0.92) ** 0.9;
    const idleBoost = rpm < this.car.idle + 200 ? 0.72 : 1;
    return this.car.torque * (0.28 + 0.72 * shape) * idleBoost;
  }

  private solveRpm(throttle: number) {
    const low = this.drive === "4L" ? this.car.lowRatio : 1;
    const ratio = Math.abs(this.gearRatio()) * this.car.finalDrive * low;
    const groundRpm = (Math.abs(this.speedMs()) / Math.max(0.2, this.car.tireRadius)) * ratio * (60 / TAU);
    const flare = this.car.idle + throttle * (this.car.redline * 0.96 - this.car.idle);
    const slip = clamp(this.wheelSpin, 0, 1);
    const target = clamp(groundRpm * (1 - slip * 0.35) + flare * (this.airborne ? 1 : slip * 0.85), this.car.idle, this.car.redline);
    const blended = this.airborne ? flare : Math.max(this.car.idle, target);
    return this.rpm + (blended - this.rpm) * 0.45;
  }

  private groundRpm() {
    const low = this.drive === "4L" ? this.car.lowRatio : 1;
    const ratio = Math.abs(this.gearRatio()) * this.car.finalDrive * low;
    return (Math.abs(this.speedMs()) / Math.max(0.2, this.car.tireRadius)) * ratio * (60 / TAU);
  }

  private autoShift(throttle: number) {
    if (this.gear < 0 || this.shiftCd > 0) return;
    const up = this.car.redline * 0.9;
    const down = this.car.redline * 0.48;
    const gr = this.groundRpm();
    if (gr > up && this.gear < this.car.gears.length && throttle > 0.55 && this.wheelSpin < 0.85) {
      this.gear += 1;
      this.shiftCd = 0.36;
      this.rpm *= 0.74;
    } else if (gr < down && this.gear > 1 && throttle > 0.25) {
      this.gear -= 1;
      this.shiftCd = 0.28;
      this.rpm = Math.min(this.car.redline * 0.8, this.rpm * 1.28);
    }
  }

  private topSpeed() {
    const topGear = this.car.gears[this.car.gears.length - 1] * this.car.finalDrive * (this.drive === "4L" ? this.car.lowRatio : 1);
    return ((this.car.redline * TAU) / 60 / topGear) * this.car.tireRadius * 1.02;
  }
}

function wheel(x: number, z: number, rear: boolean): WheelState {
  return {
    x,
    z,
    rear,
    steer: !rear,
    omega: 0,
    compression: 0,
    grounded: false,
    spin: 0,
    slip: 0,
    load: 0,
    suspLen: 0.3,
    contact: { x: 0, y: 0, z: 0 },
    normal: { x: 0, y: 1, z: 0 },
  };
}

function avg(a: number[]) {
  return a.reduce((s, v) => s + v, 0) / a.length;
}

function lerp(a: number, b: number, t: number) {
  return a + (b - a) * clamp(t, 0, 1);
}

function raycast(origin: Vec3, dirIn: Vec3, maxDist: number, field: TerrainField) {
  const dir = norm(dirIn);
  const h0 = field.height(origin.x, origin.z);
  if (origin.y < h0 && dir.y <= 0) {
    return {
      dist: 0,
      point: { x: origin.x, y: h0, z: origin.z },
      normal: field.normal(origin.x, origin.z),
    };
  }
  const steps = 5;
  let prevT = 0;
  let prevAbove = origin.y >= h0;
  for (let i = 1; i <= steps; i++) {
    const t = (maxDist * i) / steps;
    const p = madd(origin, dir, t);
    const h = field.height(p.x, p.z);
    const above = p.y >= h;
    if (prevAbove && !above) {
      let lo = prevT;
      let hi = t;
      for (let k = 0; k < 5; k++) {
        const mid = (lo + hi) * 0.5;
        const pm = madd(origin, dir, mid);
        if (pm.y >= field.height(pm.x, pm.z)) lo = mid;
        else hi = mid;
      }
      const point = madd(origin, dir, hi);
      const hh = field.height(point.x, point.z);
      point.y = hh;
      return { dist: hi, point, normal: field.normal(point.x, point.z) };
    }
    prevT = t;
    prevAbove = above;
  }
  return null;
}
