import { createRootRoute, HeadContent, Outlet, Scripts } from "@tanstack/react-router";
import { AuthProvider } from "@/lib/auth/provider";
import { PreviewHostBridge } from "@/components/preview-host-bridge";
import appCss from "../styles.css?url";

export const Route = createRootRoute({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, viewport-fit=cover" },
      { title: "تطعيس | تحدي الكثبان" },
      { name: "theme-color", content: "#17130f" },
      { name: "description", content: "لعبة تطعيس ثلاثية الأبعاد مستوحاة من كثبان الصحراء والتحكم الواقعي بالمركبات." },
    ],
    links: [{ rel: "stylesheet", href: appCss }],
  }),
  component: () => (
    <html lang="ar" dir="rtl" suppressHydrationWarning>
      <head><HeadContent /></head>
      <body>
        <PreviewHostBridge />
        <AuthProvider><Outlet /></AuthProvider>
        <Scripts />
      </body>
    </html>
  ),
});
