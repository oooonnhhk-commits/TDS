import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import * as THREE from "three";
import { CARS, defaultUpgrades, resolveCar, type CarId } from "../game/cars";
import { dunes } from "../game/terrain";
import { Vehicle, type DriveInput } from "../game/vehicle";

export const Route = createFileRoute("/")({ component: GamePage });
const blankInput = (): DriveInput => ({ throttle: 0, brake: 0, steer: 0, handbrake: false });

function GamePage() {
  const host = useRef<HTMLDivElement>(null);
  const input = useRef<DriveInput>(blankInput());
  const [carId, setCarId] = useState<CarId>("watad");
  const [speed, setSpeed] = useState(0);
  const [drive, setDrive] = useState("4H");
  const [bog, setBog] = useState(0);
  const [slip, setSlip] = useState(0);
  const [wheelSpin, setWheelSpin] = useState(0);
  const [airborne, setAirborne] = useState(false);
  const [ready, setReady] = useState(false);
  const vehicleRef = useRef<Vehicle | null>(null);
  const resetRef = useRef<(() => void) | null>(null);

  useEffect(() => {
    const mount = host.current;
    if (!mount) return;
    let alive = true;
    const scene = new THREE.Scene();
    scene.background = new THREE.Color("#d9a86e");
    scene.fog = new THREE.Fog("#d9a86e", 90, 360);
    const camera = new THREE.PerspectiveCamera(62, 1, 0.1, 700);
    const renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: "high-performance" });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.5));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    mount.appendChild(renderer.domElement);

    scene.add(new THREE.HemisphereLight(0xffe8c6, 0x66503b, 2.0));
    const sun = new THREE.DirectionalLight(0xfff0d8, 3.1);
    sun.position.set(-70, 110, 45); sun.castShadow = true; sun.shadow.mapSize.set(1024, 1024); scene.add(sun);

    const size = 440, segments = 150;
    const geometry = new THREE.PlaneGeometry(size, size, segments, segments);
    geometry.rotateX(-Math.PI / 2);
    const positions = geometry.attributes.position;
    const colors: number[] = [];
    const sandA = new THREE.Color("#c99a60"), sandB = new THREE.Color("#e0b77d"), sandDark = new THREE.Color("#9b7045");
    for (let i = 0; i < positions.count; i++) {
      const x = positions.getX(i), z = positions.getZ(i);
      positions.setY(i, dunes.height(x, z));
      const h = dunes.height(x, z);
      const col = h > 15 ? sandDark : (Math.sin(x * 0.035 + z * 0.018) > 0 ? sandA : sandB);
      colors.push(col.r, col.g, col.b);
    }
    geometry.setAttribute("color", new THREE.Float32BufferAttribute(colors, 3));
    geometry.computeVertexNormals();
    const groundMaterial = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 1 });
    const ground = new THREE.Mesh(geometry, groundMaterial);
    ground.receiveShadow = true; scene.add(ground);

    // Each vehicle has its own original low-poly silhouette; no unlicensed logos or model files.
    const carDef = CARS.find(c => c.id === carId) ?? CARS[0];
    const carGroup = new THREE.Group(); scene.add(carGroup);
    const bodyMat = new THREE.MeshStandardMaterial({ color: carDef.defaultColor, roughness: 0.48, metalness: 0.12 });
    const darkMat = new THREE.MeshStandardMaterial({ color: "#242321", roughness: 0.82 });
    const trimMat = new THREE.MeshStandardMaterial({ color: "#55534e", roughness: 0.52, metalness: 0.62 });
    const glassMat = new THREE.MeshStandardMaterial({ color: "#344950", roughness: 0.2, metalness: 0.16 });
    const lampMat = new THREE.MeshStandardMaterial({ color: "#f6e8bd", emissive: "#5b4623", emissiveIntensity: 0.35, roughness: 0.25 });
    const redLampMat = new THREE.MeshStandardMaterial({ color: "#8d241e", emissive: "#3e0907", emissiveIntensity: 0.3 });
    const carGeometries: THREE.BufferGeometry[] = [];
    const wheelVisuals: { pivot: THREE.Group; spin: THREE.Group }[] = [];
    const addBox = (size: [number, number, number], at: [number, number, number], material: THREE.Material, rx = 0, ry = 0, rz = 0) => {
      const mesh = new THREE.Mesh(new THREE.BoxGeometry(...size), material);
      mesh.position.set(...at); mesh.rotation.set(rx, ry, rz); mesh.castShadow = true; mesh.receiveShadow = true;
      carGroup.add(mesh); carGeometries.push(mesh.geometry); return mesh;
    };
    const addWheelArch = (x: number, z: number) => {
      const archGeo = new THREE.TorusGeometry(carDef.tireRadius + 0.045, 0.055, 6, 18);
      carGeometries.push(archGeo);
      const arch = new THREE.Mesh(archGeo, darkMat);
      arch.position.set(x, 0.55, z); arch.rotation.y = Math.PI / 2; arch.castShadow = true; carGroup.add(arch);
    };
    const overallLength = carDef.wheelbase + 1.0;
    addBox([carDef.track + 0.18, 0.4, overallLength], [0, 0.91, -0.03], darkMat);

    if (carId === "shas06") {
      const front = carDef.wheelbase * 0.5 + 0.48;
      const rear = -carDef.wheelbase * 0.5 - 0.45;
      addBox([carDef.track + 0.15, 0.48, carDef.wheelbase + 0.86], [0, 0.98, 0], bodyMat);
      addBox([1.84, 0.25, 1.08], [0, 1.27, 1.16], bodyMat, -0.015);
      addBox([1.65, 0.76, 1.43], [0, 1.58, -0.12], bodyMat);
      addBox([1.57, 0.13, 1.25], [0, 2.02, -0.15], bodyMat);
      addBox([1.49, 0.43, 0.045], [0, 1.65, 0.61], glassMat, -0.12);
      addBox([1.39, 0.38, 0.04], [0, 1.64, -0.87], glassMat, 0.1);
      for (const x of [-0.84, 0.84]) {
        addBox([0.045, 0.34, 0.46], [x, 1.68, -0.48], glassMat);
        addBox([0.045, 0.34, 0.42], [x, 1.68, 0.1], glassMat);
        addBox([0.08, 0.18, 0.16], [x * 1.12, 1.44, 0.42], bodyMat, 0, x < 0 ? -0.1 : 0.1);
      }
      // Open utility bed, high side rails, and a square tailgate give the 2006 pickup its silhouette.
      addBox([1.78, 0.11, 1.3], [0, 1.12, rear + 0.2], darkMat);
      addBox([0.12, 0.31, 1.48], [-0.9, 1.29, rear + 0.23], bodyMat);
      addBox([0.12, 0.31, 1.48], [0.9, 1.29, rear + 0.23], bodyMat);
      addBox([1.8, 0.3, 0.12], [0, 1.28, rear - 0.51], bodyMat);
      addBox([0.72, 0.29, 0.055], [0, 1.0, front], trimMat);
      for (let i = 0; i < 7; i++) addBox([0.035, 0.22, 0.035], [-0.29 + i * 0.097, 1.0, front + 0.03], darkMat);
      for (const x of [-0.68, 0.68]) {
        addBox([0.38, 0.2, 0.08], [x, 1.17, front], lampMat);
        addBox([0.12, 0.1, 0.09], [x * 1.27, 0.86, front], redLampMat);
      }
      addBox([2.12, 0.16, 0.17], [0, 0.74, front + 0.06], trimMat);
      addBox([2.04, 0.15, 0.16], [0, 0.75, rear - 0.55], trimMat);
      const archX = carDef.track / 2 + carDef.tireWidth / 2 + 0.03;
      for (const x of [-archX, archX]) {
        for (const z of [-carDef.wheelbase / 2, carDef.wheelbase / 2]) addWheelArch(x, z);
      }
    } else if (carId === "lexus05") {
      const front = carDef.wheelbase * 0.5 + 0.5;
      const rear = -carDef.wheelbase * 0.5 - 0.5;
      addBox([carDef.track + 0.2, 0.56, overallLength], [0, 0.98, -0.06], bodyMat);
      addBox([1.9, 0.28, 1.13], [0, 1.25, 1.28], bodyMat, -0.025);
      addBox([1.76, 0.82, 2.03], [0, 1.57, -0.2], bodyMat);
      addBox([1.68, 0.13, 1.82], [0, 2.04, -0.21], bodyMat);
      addBox([1.55, 0.42, 0.05], [0, 1.68, 0.82], glassMat, -0.2);
      addBox([1.5, 0.4, 0.05], [0, 1.68, -1.23], glassMat, 0.18);
      for (const x of [-0.89, 0.89]) {
        for (const z of [-0.78, -0.19, 0.36]) addBox([0.045, 0.39, 0.48], [x, 1.69, z], glassMat);
        addBox([0.08, 0.12, 0.15], [x * 1.08, 1.43, 0.62], bodyMat, 0, x < 0 ? -0.08 : 0.08);
        addBox([0.1, 0.11, 1.7], [x * 1.03, 0.72, -0.15], trimMat);
      }
      addBox([0.66, 0.31, 0.055], [0, 1.0, front], trimMat);
      for (let i = 0; i < 6; i++) addBox([0.035, 0.25, 0.035], [-0.22 + i * 0.088, 1.0, front + 0.03], darkMat);
      for (const x of [-0.72, 0.72]) {
        addBox([0.42, 0.18, 0.08], [x, 1.16, front], lampMat);
        addBox([0.22, 0.1, 0.07], [x, 0.98, front], lampMat);
        addBox([0.19, 0.24, 0.06], [x, 1.06, rear], redLampMat);
      }
      addBox([2.12, 0.17, 0.17], [0, 0.72, front + 0.08], trimMat);
      addBox([2.06, 0.15, 0.17], [0, 0.72, rear - 0.08], trimMat);
      const archX = carDef.track / 2 + carDef.tireWidth / 2 + 0.03;
      for (const x of [-archX, archX]) {
        for (const z of [-carDef.wheelbase / 2, carDef.wheelbase / 2]) addWheelArch(x, z);
      }
    } else {
      // Existing original 4x4 variants keep their own pickup/wagon proportions.
      const front = carDef.wheelbase * 0.5 + 0.48;
      const rear = -carDef.wheelbase * 0.5 - 0.42;
      addBox([carDef.track + 0.15, 0.48, overallLength], [0, 0.98, -0.02], bodyMat);
      if (carDef.body === "bed") {
        addBox([1.82, 0.25, 1.02], [0, 1.27, 1.14], bodyMat);
        addBox([1.67, 0.73, 1.38], [0, 1.57, -0.14], bodyMat);
        addBox([1.58, 0.13, 1.2], [0, 2.0, -0.15], bodyMat);
        addBox([1.5, 0.42, 0.045], [0, 1.64, 0.58], glassMat, -0.14);
        addBox([1.42, 0.37, 0.04], [0, 1.63, -0.82], glassMat, 0.1);
        addBox([1.76, 0.1, 1.24], [0, 1.11, rear + 0.18], darkMat);
        addBox([0.11, 0.25, 1.42], [-0.89, 1.26, rear + 0.22], bodyMat);
        addBox([0.11, 0.25, 1.42], [0.89, 1.26, rear + 0.22], bodyMat);
        addBox([1.78, 0.25, 0.12], [0, 1.26, rear - 0.48], bodyMat);
      } else {
        addBox([1.92, 0.3, 1.02], [0, 1.24, 1.18], bodyMat);
        addBox([1.73, 0.82, 2.0], [0, 1.56, -0.18], bodyMat);
        addBox([1.63, 0.13, 1.82], [0, 2.02, -0.18], bodyMat);
        addBox([1.52, 0.42, 0.05], [0, 1.68, 0.78], glassMat, -0.18);
        addBox([1.48, 0.4, 0.05], [0, 1.67, -1.2], glassMat, 0.16);
        for (const x of [-0.88, 0.88]) for (const z of [-0.74, -0.16, 0.36]) addBox([0.04, 0.38, 0.46], [x, 1.67, z], glassMat);
      }
      addBox([0.65, 0.28, 0.055], [0, 1.0, front], trimMat);
      for (const x of [-0.7, 0.7]) addBox([0.38, 0.19, 0.07], [x, 1.14, front], lampMat);
      addBox([2.1, 0.16, 0.17], [0, 0.73, front + 0.04], trimMat);
      addBox([2.0, 0.15, 0.16], [0, 0.73, rear - 0.04], trimMat);
    }

    // Separate steering and rolling pivots let tyres visibly steer, spin, and follow suspension travel.
    const tireMat = new THREE.MeshStandardMaterial({ color: "#191a1a", roughness: 0.95 });
    const rimMat = new THREE.MeshStandardMaterial({ color: "#777b7c", roughness: 0.38, metalness: 0.75 });
    const wheelPositions = [
      [carDef.track / 2, carDef.wheelbase / 2], [-carDef.track / 2, carDef.wheelbase / 2],
      [carDef.track / 2, -carDef.wheelbase / 2], [-carDef.track / 2, -carDef.wheelbase / 2],
    ];
    for (let i = 0; i < wheelPositions.length; i++) {
      const [x, z] = wheelPositions[i];
      const pivot = new THREE.Group(); pivot.position.set(x, 0.53, z); carGroup.add(pivot);
      const spin = new THREE.Group(); pivot.add(spin);
      const tyre = new THREE.Mesh(new THREE.CylinderGeometry(carDef.tireRadius, carDef.tireRadius, carDef.tireWidth, 20), tireMat);
      tyre.rotation.z = Math.PI / 2; tyre.castShadow = true; tyre.receiveShadow = true; spin.add(tyre); carGeometries.push(tyre.geometry);
      const hubGeo = new THREE.CylinderGeometry(carDef.tireRadius * 0.53, carDef.tireRadius * 0.53, 0.04, 12); hubGeo.rotateZ(Math.PI / 2); carGeometries.push(hubGeo);
      for (const side of [-1, 1]) {
        const hub = new THREE.Mesh(hubGeo, rimMat); hub.position.x = side * (carDef.tireWidth * 0.37); hub.castShadow = true; spin.add(hub);
        const capGeo = new THREE.CylinderGeometry(carDef.tireRadius * 0.17, carDef.tireRadius * 0.17, 0.045, 10); capGeo.rotateZ(Math.PI / 2); carGeometries.push(capGeo);
        const cap = new THREE.Mesh(capGeo, darkMat); cap.position.x = side * (carDef.tireWidth * 0.45); spin.add(cap);
      }
      wheelVisuals.push({ pivot, spin });
    }

    // Lightweight world-space sand spray. It appears only when tyres work loose sand,
    // giving wheelspin and throttle a visible response without a heavy particle engine.
    const dustCount = 128;
    const dustPositions = new Float32Array(dustCount * 3);
    const dustLives = new Float32Array(dustCount);
    const dustVelocities = Array.from({ length: dustCount }, () => new THREE.Vector3());
    for (let i = 0; i < dustCount; i++) dustPositions[i * 3 + 1] = -1000;
    const dustGeometry = new THREE.BufferGeometry();
    dustGeometry.setAttribute("position", new THREE.BufferAttribute(dustPositions, 3));
    const dustMaterial = new THREE.PointsMaterial({ color: "#d2a16a", size: 0.32, transparent: true, opacity: 0.42, depthWrite: false, sizeAttenuation: true });
    const dustCloud = new THREE.Points(dustGeometry, dustMaterial); dustCloud.frustumCulled = false; scene.add(dustCloud);
    let dustCursor = 0;
    let dustAccumulator = 0;
    let dustFrames = 0;
    const spawnDust = (wheelIndex: number, intensity: number) => {
      const i = dustCursor++ % dustCount;
      const source = wheelVisuals[wheelIndex]?.pivot;
      if (!source) return;
      const p = source.getWorldPosition(new THREE.Vector3());
      p.x += (Math.random() - 0.5) * 0.22; p.y += 0.04 + Math.random() * 0.14; p.z += (Math.random() - 0.5) * 0.22;
      dustPositions[i * 3] = p.x; dustPositions[i * 3 + 1] = p.y; dustPositions[i * 3 + 2] = p.z;
      const rearward = new THREE.Vector3(0, 0, -1).applyQuaternion(carGroup.quaternion);
      dustVelocities[i].set(
        vehicle.vel.x * 0.22 + rearward.x * (1.0 + intensity * 2.5) + (Math.random() - 0.5) * 1.4,
        0.4 + Math.random() * (0.8 + intensity * 0.9),
        vehicle.vel.z * 0.22 + rearward.z * (1.0 + intensity * 2.5) + (Math.random() - 0.5) * 1.4,
      );
      dustLives[i] = 0.38 + Math.random() * 0.52;
    };

    let currentCarId = carId;
    const makeVehicle = () => {
      const def = CARS.find(c => c.id === currentCarId) ?? CARS[0];
      bodyMat.color.set(def.defaultColor);
      const v = new Vehicle(resolveCar(def, defaultUpgrades(def)));
      v.drive = "4H"; v.place(0, 42, 0, dunes); vehicleRef.current = v;
      return v;
    };
    let vehicle = makeVehicle();
    resetRef.current = () => { vehicle = makeVehicle(); };
    const resize = () => {
      if (!mount || !alive) return;
      const w = Math.max(1, mount.clientWidth), h = Math.max(1, mount.clientHeight);
      renderer.setSize(w, h, false); camera.aspect = w / h; camera.updateProjectionMatrix();
    };
    const ro = new ResizeObserver(resize); ro.observe(mount); resize();
    let last = performance.now(), hudLast = 0, raf = 0;
    const animate = (now: number) => {
      if (!alive) return;
      raf = requestAnimationFrame(animate);
      const dt = Math.min(0.04, Math.max(0.001, (now - last) / 1000)); last = now;
      vehicle.step(dt, input.current, dunes);
      const p = vehicle.pos;
      carGroup.position.set(p.x, p.y - 1.0, p.z);
      carGroup.quaternion.set(vehicle.quat.x, vehicle.quat.y, vehicle.quat.z, vehicle.quat.w);
      const t = vehicle.telemetry();
      wheelVisuals.forEach((visual, i) => {
        const state = vehicle.wheels[i];
        visual.pivot.position.set(state.x, 0.82 - Math.max(0.02, state.suspLen), state.z);
        visual.pivot.rotation.y = state.steer ? -vehicle.steerVisual : 0;
        visual.spin.rotation.x += state.omega * dt;
      });
      const looseSand = t.surface === "soft" || t.surface === "medium";
      if (looseSand && input.current.throttle > 0.22 && (Math.abs(t.speedMs) > 1.2 || t.wheelSpin > 0.15)) {
        dustAccumulator += dt * (10 + Math.min(1.5, t.wheelSpin) * 18 + Math.abs(t.speedMs) * 0.65);
        while (dustAccumulator >= 1) {
          spawnDust(2 + (Math.random() < 0.5 ? 0 : 1), Math.min(1.5, t.wheelSpin));
          dustAccumulator -= 1;
        }
      } else {
        dustAccumulator = Math.max(0, dustAccumulator - dt * 3);
      }
      for (let i = 0; i < dustCount; i++) {
        if (dustLives[i] <= 0) { dustPositions[i * 3 + 1] = -1000; continue; }
        dustLives[i] -= dt;
        dustPositions[i * 3] += dustVelocities[i].x * dt;
        dustPositions[i * 3 + 1] += dustVelocities[i].y * dt;
        dustPositions[i * 3 + 2] += dustVelocities[i].z * dt;
        dustVelocities[i].y -= 1.25 * dt;
        dustVelocities[i].multiplyScalar(Math.exp(-0.45 * dt));
        if (dustLives[i] <= 0) dustPositions[i * 3 + 1] = -1000;
      }
      dustGeometry.attributes.position.needsUpdate = true;
      if (++dustFrames % 12 === 0) dustGeometry.computeBoundingSphere();
      const yaw = t.yaw;
      const behind = new THREE.Vector3(p.x + Math.sin(yaw) * 10.5, p.y + 5.2, p.z + Math.cos(yaw) * 10.5);
      camera.position.lerp(behind, 1 - Math.exp(-3.8 * dt));
      camera.lookAt(p.x - Math.sin(yaw) * 1.5, p.y + 0.75, p.z - Math.cos(yaw) * 1.5);
      if (now - hudLast > 130) {
        setSpeed(Math.round(Math.abs(t.speed))); setDrive(t.drive); setBog(t.bog);
        setSlip(t.slip); setWheelSpin(t.wheelSpin); setAirborne(t.airborne); hudLast = now;
      }
      renderer.render(scene, camera);
    };
    raf = requestAnimationFrame(animate); setReady(true);
    const onKeyDown = (e: KeyboardEvent) => {
      const k = e.key.toLowerCase();
      if (["arrowup", "arrowdown", "arrowleft", "arrowright", " "].includes(k)) e.preventDefault();
      if (k === "w" || k === "arrowup") input.current.throttle = 1;
      if (k === "s" || k === "arrowdown") input.current.brake = 1;
      if (k === "a" || k === "arrowleft") input.current.steer = -1;
      if (k === "d" || k === "arrowright") input.current.steer = 1;
      if (k === " ") input.current.handbrake = true;
      if (k === "r") resetRef.current?.();
      if (k === "1") vehicle.tryDrive("2H"); if (k === "2") vehicle.tryDrive("4H"); if (k === "3") vehicle.tryDrive("4L");
    };
    const onKeyUp = (e: KeyboardEvent) => {
      const k = e.key.toLowerCase();
      if (k === "w" || k === "arrowup") input.current.throttle = 0;
      if (k === "s" || k === "arrowdown") input.current.brake = 0;
      if (["a", "arrowleft", "d", "arrowright"].includes(k)) input.current.steer = 0;
      if (k === " ") input.current.handbrake = false;
    };
    window.addEventListener("keydown", onKeyDown); window.addEventListener("keyup", onKeyUp);
    return () => {
      alive = false; cancelAnimationFrame(raf); ro.disconnect();
      window.removeEventListener("keydown", onKeyDown); window.removeEventListener("keyup", onKeyUp);
      renderer.dispose(); geometry.dispose(); groundMaterial.dispose();
      for (const geo of carGeometries) geo.dispose();
      dustGeometry.dispose(); dustMaterial.dispose();
      for (const mat of [bodyMat, darkMat, trimMat, glassMat, lampMat, redLampMat, tireMat, rimMat]) mat.dispose();
      mount.removeChild(renderer.domElement);
    };
  // Reset/rebuild the visual vehicle when car selection changes.
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [carId]);

  const hold = (key: keyof DriveInput, value: number | boolean) => (e: React.PointerEvent) => {
    e.preventDefault(); (e.currentTarget as HTMLElement).setPointerCapture?.(e.pointerId);
    (input.current[key] as number | boolean) = value;
  };
  const release = (key: keyof DriveInput) => (e: React.PointerEvent) => { e.preventDefault(); input.current[key] = (key === "handbrake" ? false : 0) as never; };

  return <main className="game-shell">
    <div ref={host} className="game-view" aria-label="مشهد لعبة التطعيس ثلاثي الأبعاد" />
    <header className="top-hud"><div><div className="eyebrow">تحدي الكثبان</div><h1>تطعيس <span>3D</span></h1></div><div className="speed-card"><strong>{speed}</strong><small>كم/س</small></div><button className="icon-button" onClick={() => resetRef.current?.()} aria-label="إعادة السيارة">↻</button></header>
    <section className="garage"><div className="section-label">اختر مركبتك</div><div className="car-picker">{CARS.map(car => <button key={car.id} className={`car-option ${carId === car.id ? "selected" : ""}`} onClick={() => { input.current = blankInput(); setCarId(car.id); }}><strong>{car.name}</strong><small>{car.clazz}</small></button>)}</div></section>
    <div className="telemetry"><span>الدفع <b>{drive}</b></span><span>الغرز <b>{Math.round(bog * 100)}%</b></span><span>انزلاق <b>{Math.round(Math.min(1, slip) * 100)}%</b></span><span>دوران الإطارات <b>{Math.round(Math.min(1.5, wheelSpin) * 100)}%</b></span><span className="live-dot">● {airborne ? "بالهواء" : ready ? "تماسك الإطارات" : "جارٍ التحميل"}</span></div>
    <div className="controls"><div className="steering"><button aria-label="لف يسار" onPointerDown={hold("steer", -1)} onPointerUp={release("steer")} onPointerCancel={release("steer")} onContextMenu={e => e.preventDefault()}>◀</button><button aria-label="لف يمين" onPointerDown={hold("steer", 1)} onPointerUp={release("steer")} onPointerCancel={release("steer")} onContextMenu={e => e.preventDefault()}>▶</button></div><div className="pedals"><button className="brake" onPointerDown={hold("brake", 1)} onPointerUp={release("brake")} onPointerCancel={release("brake")}>فرامل</button><button className="gas" onPointerDown={hold("throttle", 1)} onPointerUp={release("throttle")} onPointerCancel={release("throttle")}>بنزين</button><button className="handbrake" onPointerDown={hold("handbrake", true)} onPointerUp={release("handbrake")} onPointerCancel={release("handbrake")}>هاند بريك</button></div></div>
    <footer className="bottom-bar"><span>WASD / الأسهم للتحكم على الكمبيوتر</span><div>{(["2H", "4H", "4L"] as const).map(m => <button key={m} className={drive === m ? "drive-active" : ""} onClick={() => { if (vehicleRef.current?.tryDrive(m)) setDrive(m); }}>{m}</button>)}</div></footer>
  </main>;
}
